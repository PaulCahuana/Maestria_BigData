root_path = "root_path"
checkpoint_path = "checkpoint_path"
org = "org"
app_env = "app_env"
version = "version"

# demo
demo_raw_path = "demo_raw_path"
demo_raw_csv_path = "demo_raw_csv_path"
demo_ml_model_path = "demo_ml_model_path"
demo_predictions_csv_path = "demo_predictions_csv_path"